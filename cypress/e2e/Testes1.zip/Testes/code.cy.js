import { faker } from '@faker-js/faker';
import { first } from 'lodash';

describe('Suite de Teste', () => { 

  const baseUrl = 'https://commerce-hmg-fiatbarigui.mob1.one/';

  var postCode = faker.address.zipCode();
  var findProd = 'cox'

  beforeEach(() => {
    cy.visit(baseUrl);
  })
  
  it('', () => {
    cy.get('.search-bar .MuiInputBase-input').first().type(findProd);
    cy.get('.search-bar .MuiButton-containedPrimary').first().click();
    cy.wait(3000)
    cy.get('.MuiGrid-item .MuiGrid-root:nth-child(1) a.section').click();

  })
});